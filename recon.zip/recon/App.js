import * as React from 'react';
import { View, Text, TouchableOpacity, Stylesheet } from 'react-native';
import { createSwitchNavigator, createAppContainer } from 'react-navigation';
import HomeScreen from './screens/HomeScreen';
import SignUpScreen from './screens/SignUpScreen';
import LogInScreen from './screens/LogInScreen';
import ReconScreen from './screens/ReconScreen';

export default class App extends React.Component {
  render() {
    return <AppContainer />;
  }
}

const AppNavigator = createSwitchNavigator({
  HomeScreen: HomeScreen,
  SignUpScreen: SignUpScreen,
  LogInScreen: LogInScreen,
  ReconScreen: ReconScreen
});

const AppContainer = createAppContainer(AppNavigator);