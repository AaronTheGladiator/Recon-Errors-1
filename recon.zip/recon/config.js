import firebase from 'firebase';
require('@firebase/firestore');

const firebaseConfig = {
  apiKey: "AIzaSyCC-amSEC4FPyY4mz_wRb1U2ug4bT70ZKA",
  authDomain: "recon-18ce8.firebaseapp.com",
  databaseURL: 'https://recon-18ce8.firebaseio.com',
  projectId: "recon-18ce8",
  storageBucket: "recon-18ce8.appspot.com",
  messagingSenderId: "124697789945",
  appId: "1:124697789945:web:179b82b5e38ed8d3972928",
};

// Initialize Firebase
if(!firebase.apps.length){
firebase.initializeApp(firebaseConfig);
}

export default firebase.firestore();