import * as React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import db from '../config';
import firebase from 'firebase';

export default class ReconScreen extends React.Component {
  constructor() {
    super();
    this.state = {
      emailId: firebase.auth().currentUser.email,
      gender: '',
      dateOfBirth: '',
      country: ''
    }
  }
  getGender() {
    db.collection('users').where('email_id', '==', this.state.emailId).get()
  }
  render() {
    return (
      <View style={{ backgroundColor: 'pink' }}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Recon</Text>
        </View>
        <View></View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    borderTopWidth: 5,
    borderBottomWidth: 5,
    backgroundColor: 'green',
  },
  headerText: {
    fontSize: 25,
    fontWeight: 500,
    color: 'orange',
    alignSelf: 'center',
    margin: 10,
    padding: 5,
  },
});
