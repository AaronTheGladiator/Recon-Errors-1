import * as React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import db from '../config';
import firebase from 'firebase';

export default class HomeScreen extends React.Component {
  render() {
    return (
      <View style={{ backgroundColor: 'pink' }}>
        <View style={styles.header}>
          <Text style={styles.headerText}>Recon</Text>
          <Text style={styles.subHeader}>For all your needs and tasks</Text>
        </View>
        <View>
          <Image style={styles.logo} source={require('../assets/Recon.PNG')} />
        </View>
        <View>
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              this.props.navigation.navigate('SignUpScreen');
            }}>
            <Text style={styles.buttonText}>Sign Up</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              this.props.navigation.navigate('LogInScreen');
            }}>
            <Text style={styles.buttonText}>Log In</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    borderTopWidth: 5,
    borderBottomWidth: 5,
    backgroundColor: 'green',
  },
  headerText: {
    fontSize: 25,
    fontWeight: 500,
    color: 'orange',
    alignSelf: 'center',
    margin: 10,
    padding: 5,
  },
  subHeader: {
    fontSize: 20,
    fontWeight: 250,
    color: 'pink',
    alignSelf: 'center',
    margin: 10,
    padding: 5,
    marginTop: -20,
  },
  logo: {
    height: 170,
    width: 300,
    margin: 10,
    alignSelf: 'center',
  },
  button: {
    height: 50,
    width: 300,
    borderWidth: 5,
    borderRadius: 10,
    alignItems: 'center',
    margin: 25,
    padding: 10,
    backgroundColor: 'orange',
    marginLeft: 17,
  },
  buttonText: {
    fontSize: 20,
    fontWeight: 375,
    color: 'green',
    marginTop: -5,
  },
});
