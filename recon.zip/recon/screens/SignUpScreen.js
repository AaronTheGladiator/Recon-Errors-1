import * as React from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  Alert,
  Modal,
  ScrollView,
  KeyboardAvoidingView,
} from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import db from '../config';
import firebase from 'firebase';

export default class SignUpScreen extends React.Component {
  constructor() {
    super();
    this.state = {
      emailId: '',
      password: '',
      confirmPassword: '',
      name: '',
      gender: '',
      dateOfBirth: '',
      country: '',
    };
  }
  userSignUp = (emailId, password, confirmPassword) => {
    if (password !== confirmPassword) {
      return Alert.alert("Passwords don't match.");
    } else {
      firebase
        .auth()
        .createUserWithEmailAndPassword(emailId, password)
        .then(() => {
          db.collection('users').add({
            email_id: this.state.emailId,
            name: this.state.name,
            gender: this.state.gender,
            date_of_birth: this.state.dateOfBirth,
            country: this.state.country,
          });
          return Alert.alert('Sign Up Successful!', '', [
            {
              text: 'OK',
              onPress: () => this.props.navigation.navigate('HomeScreen'),
            },
          ]);
        })
        .catch((error) => {
          var errorCode = error.code;
          var errorMessage = error.message;
          return Alert.alert(errorMessage);
        });
    }
  };

  showModal = () => {
    return (
      <Modal
        animationType="fade"
        transparent={true}
        visible={this.state.isModalVisible}>
        <View style={styles.modalContainer}>
          <ScrollView style={{ width: '100%' }}>
            <KeyboardAvoidingView style={styles.KeyboardAvoidingView}>
              <Text style={styles.modalTitle}>Sign Up</Text>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'email'}
                keyboardType={'email-address'}
                onChangeText={(text) => {
                  this.setState({
                    emailId: text,
                  });
                }}
              />
              <Text style={styles.label}>Password</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'password'}
                secureTextEntry={true}
                maxLength={10}
                onChangeText={(text) => {
                  this.setState({
                    password: text,
                  });
                }}
              />
              <Text style={styles.label}>Confirm Password</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'confirm password'}
                secureTextEntry={true}
                maxLength={10}
                onChangeText={(text) => {
                  this.setState({
                    confirmPassword: text,
                  });
                }}
              />
              <Text style={styles.label}>Name</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'name'}
                onChangeText={(text) => {
                  this.setState({
                    emailId: text,
                  });
                }}
              />
              <Text style={styles.label}>Gender</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'gender'}
                onChangeText={(text) => {
                  this.setState({
                    gender: text,
                  });
                }}
              />
              <Text style={styles.label}>Date of Birth</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'date of birth'}
                onChangeText={(text) => {
                  this.setState({
                    dateOfBirth: text,
                  });
                }}
              />
              <Text style={styles.label}>Country</Text>
              <TextInput
                style={styles.formTextInput}
                placeholder={'country'}
                onChangeText={(text) => {
                  this.setState({
                    country: text,
                  });
                }}
              />
              <View style={styles.modalBackButton}>
                <TouchableOpacity
                  style={styles.signUpButton}
                  onPress={() => {
                    this.userSignUp(
                      this.state.emailId,
                      this.state.password,
                      this.state.confirmPassword
                    );
                    this.props.navigation.navigate('HomeScreen');
                  }}>
                  <Text style={styles.signUpButtonText}>Sign Up</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.modalBackButton}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => {
                    this.props.navigation.navigate('HomeScreen');
                  }}>
                  <Text style={{ color: 'orange' }}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </KeyboardAvoidingView>
          </ScrollView>
        </View>
      </Modal>
    );
  };
  render() {
    return <View style={{ backgroundColor: 'green' }}>{this.showModal()}</View>;
  }
}

const styles = StyleSheet.create({
  KeyboardAvoidingView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalTitle: {
    justifyContent: 'center',
    alignSelf: 'center',
    fontSize: 25,
    color: 'orange',
  },
  modalContainer: {
    flex: 1,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'green',
    marginTop: 25,
  },
  formTextInput: {
    width: '75%',
    height: RFValue(45),
    alignSelf: 'center',
    borderColor: 'pink',
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 20,
    padding: RFValue(10),
    marginLeft: RFValue(20),
    marginBottom: RFValue(14),
  },
  signUpButton: {
    width: 200,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 10,
    marginTop: 30,
  },
  signUpButtonText: {
    color: 'orange',
    fontSize: 15,
    fontWeight: 'bold',
  },
  cancelButton: {
    width: 200,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 5,
    marginBottom: 10,
  },

  label: {
    fontSize: RFValue(25),
    color: 'pink',
    fontWeight: 'bold',
    padding: RFValue(10),
    marginTop: 25,
  },
});
